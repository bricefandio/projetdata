import json

from utils.api_utils import get_data_from_api_and_save_to_hdfs, get_data_from_api, \
    get_data_with_pagination_from_api_and_save_to_hdfs, get_data_with_pagination_from_api


# Toutes les fonctions permettant de reccueillir les données depuis l'api
# devrons être appeler dans cette fonction
def extraction_from_api_and_save_to_hdfs(current_date: str):
    find_popular_movies_and_save(current_date)


def get_movies(current_date):
    get_data_from_api_and_save_to_hdfs(api_url="https://example.com",
                                       hdfs_path=f"/datalake/raw/tmdb/{current_date}.json")


def find_popular_movies_and_save(current_date):
    params = {
        "q": "limoges, FR",
        "appid": "eea045ed57d81cb0b2ad92319810b8c6"
    }
    get_data_from_api_and_save_to_hdfs(
        hdfs_path=f"/datalake/raw/openweathermap/weather/{current_date}.json",
        api_url="https://api.openweathermap.org/data/2.5/weather", params=params)

# def find_popular_movies_and_save(current_date):
#     params = {
#         "api_key": "888d24dde3ad84956d00e02d0161d41f",
#         "page": 1
#     }
#     data = get_data_with_pagination_from_api_and_save_to_hdfs(
#         api_url="https://api.themoviedb.org/3/movie/popular",
#         total_page_key=["total_pages"],
#         total_page=500, data_key=["results"],
#         params=params, param_page_key=["page"], hdfs_path="/sda/")
#
#     print(json.dumps(data, indent=2))
#     print(len(data))


# find_popular_movies_and_save("")
